# API de Likes Free Fire

Uma API moderna e robusta para envio de likes no Free Fire, desenvolvida com **Node.js puro** (sem TypeScript), seguindo as melhores práticas de desenvolvimento.

## 🚀 Características

- ✅ **Node.js Puro** - Sem TypeScript, apenas JavaScript
- 🔐 **Autenticação via API Key** - Sistema seguro de autenticação
- 🎨 **Interface Web Moderna** - Frontend responsivo com Bootstrap 5
- 📊 **Estrutura Organizada** - Arquitetura MVC com separação de responsabilidades
- 🛡️ **Segurança** - Helmet, CORS, Rate Limiting
- 📝 **Logging** - Morgan para registro de requisições
- 🗄️ **MongoDB** - Banco de dados NoSQL com Mongoose
- ⚡ **Performance** - Otimizado com índices e cache
- 🔄 **Graceful Shutdown** - Encerramento seguro do servidor

## 📁 Estrutura do Projeto

```
freefire-likes-api/
├── config/
│   ├── constants.js      # Constantes da aplicação
│   └── database.js       # Configuração do MongoDB
├── controllers/
│   ├── apiKeyController.js   # Lógica de geração de API keys
│   └── likesController.js    # Lógica de envio de likes
├── middleware/
│   ├── auth.js           # Middleware de autenticação
│   └── validation.js     # Middleware de validação
├── models/
│   ├── User.js           # Model de usuário
│   └── Token.js          # Model de token
├── public/
│   ├── index.html        # Página principal
│   ├── styles.css        # Estilos CSS
│   └── script.js         # JavaScript do frontend
├── routes/
│   └── api.js            # Rotas da API
├── utils/
│   └── keyGenerator.js   # Utilitários para geração de chaves
├── .env.example          # Exemplo de variáveis de ambiente
├── .gitignore            # Arquivos ignorados pelo Git
├── package.json          # Dependências e scripts
├── README.md             # Documentação
└── server.js             # Arquivo principal do servidor
```

## 🛠️ Instalação

### Pré-requisitos

- Node.js 14+ instalado
- MongoDB instalado e rodando
- npm ou yarn

### Passos

1. **Clone o repositório**

```bash
git clone <url-do-repositorio>
cd freefire-likes-api
```

2. **Instale as dependências**

```bash
npm install
```

3. **Configure as variáveis de ambiente**

Copie o arquivo `.env.example` para `.env` e configure:

```bash
cp .env.example .env
```

Edite o arquivo `.env`:

```env
PORT=3000
NODE_ENV=development
MONGO_URI=mongodb://localhost:27017/freefire-likes
EXTERNAL_API_URL=https://getvyenx.cloud/free-fire/send-likes
API_TIMEOUT=10000
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

4. **Inicie o servidor**

```bash
npm start
```

Para desenvolvimento com auto-reload:

```bash
npm run dev
```

## 📖 Uso da API

### 1. Gerar API Key

**Endpoint:** `POST /api/generate-api-key`

**Descrição:** Gera uma nova API key anônima.

**Resposta:**

```json
{
  "success": true,
  "message": "API key gerada com sucesso",
  "data": {
    "apiKey": "550e8400-e29b-41d4-a716-446655440000",
    "createdAt": "2024-01-01T00:00:00.000Z"
  }
}
```

### 2. Enviar Likes

**Endpoint:** `POST /api/send-likes`

**Headers:**

```
x-api-key: sua-api-key-aqui
Content-Type: application/json
```

**Body:**

```json
{
  "uid": "123456789",
  "region": "BR",
  "accessToken": "seu_token_aqui"
}
```

**Resposta:**

```json
{
  "success": true,
  "message": "Likes enviados com sucesso",
  "data": {
    "uid": "123456789",
    "region": "BR",
    "response": {
      "success": true
    }
  }
}
```

### 3. Recuperar Token Salvo

**Endpoint:** `GET /api/get-token`

**Headers:**

```
x-api-key: sua-api-key-aqui
```

**Resposta:**

```json
{
  "success": true,
  "message": "Token recuperado com sucesso",
  "data": {
    "accessToken": "seu_token_salvo",
    "expiresAt": "2024-01-02T00:00:00.000Z",
    "lastUsed": "2024-01-01T12:00:00.000Z"
  }
}
```

### 4. Health Check

**Endpoint:** `GET /api/health`

**Resposta:**

```json
{
  "success": true,
  "status": "OK",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "uptime": 3600
}
```

## 🌍 Regiões Válidas

- `BR` - Brasil
- `NA` - América do Norte
- `SA` - América do Sul
- `EU` - Europa
- `AS` - Ásia
- `OC` - Oceania

## 🔒 Segurança

A API implementa várias camadas de segurança:

- **Helmet** - Proteção contra vulnerabilidades comuns
- **CORS** - Controle de acesso entre origens
- **Rate Limiting** - Limite de requisições por IP
- **Validação de Dados** - Validação rigorosa de entrada
- **API Key Authentication** - Autenticação via chave única

## 📊 Melhorias Implementadas

Comparado ao código original, esta versão inclui:

1. **Arquitetura Modular** - Separação clara de responsabilidades (MVC)
2. **Constantes Centralizadas** - Gerenciamento fácil de valores fixos
3. **Tratamento de Erros Robusto** - Error handling completo
4. **Logging Profissional** - Morgan para desenvolvimento e produção
5. **Graceful Shutdown** - Encerramento seguro do servidor
6. **Índices no MongoDB** - Performance otimizada
7. **Rate Limiting** - Proteção contra abuso
8. **Documentação Completa** - Código bem documentado
9. **Frontend Aprimorado** - Interface moderna e responsiva
10. **Histórico de API Keys** - Salva no localStorage do navegador

## 🧪 Testando com Postman

1. Gere uma API key acessando `http://localhost:3000`
2. Copie a API key gerada
3. No Postman, crie uma requisição POST para `http://localhost:3000/api/send-likes`
4. Adicione o header `x-api-key` com sua chave
5. Envie o body JSON com uid, region e accessToken

## 📝 Scripts Disponíveis

- `npm start` - Inicia o servidor em produção
- `npm run dev` - Inicia o servidor em modo desenvolvimento (com auto-reload)

## 🤝 Contribuindo

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou pull requests.

## 📄 Licença

Este projeto está sob a licença MIT.

## 👨‍💻 Autor

Desenvolvido com ❤️ usando Node.js puro.

---

**Nota:** Esta é uma API educacional. Use com responsabilidade e respeite os termos de serviço do Free Fire.
